<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div id="banner">
            <img  src="Images/Banner+2+x+4_FB-01.jpg" alt="banner" style="">
        </div>
        <ul>
            <li><a class="active" href="index.php">Home</a></li>
            <li class="dropdown">
                <a href="#" class="dropbtn">Tests</a>
                <div class="dropdown-content">
                    <a href="mockquestion.php">Mock Test</a>
                    <a href="">Testing</a>                    
                </div>
            </li>
            <li class="dropdown">
                <a href="#" class="dropbtn">Courses</a>
                <div class="dropdown-content">
                    <a href="text1.php">Fallacy 1</a>
                    <a href="text2.php">Fallacy 2</a>
                </div>
            </li>           

           
            <li class="dropdown-logout">
                <a href="../project1/includes/logout.php" class="dropbtn">Logout</a>                
            </li>

        </ul>

    </body>
</html>
