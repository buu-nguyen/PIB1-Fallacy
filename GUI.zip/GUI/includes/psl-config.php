<?php


  
define("HOST", "localhost");     // Para o host com o qual você quer se conectar.
define("USER", "root");    // O nome de usuário para o banco de dados.
define("PASSWORD", "");    // A senha do banco de dados.
define("DATABASE", "project1");    // O nome do banco de dados.
//define("CAN_REGISTER", "any");*/
//define("DEFAULT_ROLE", "member");

define("SECURE", FALSE);
?>